
class Global 
{
    static let shared = Global()

    private init() { }

    func action(onExit: @escaping ()->Void) 
    {
        print("\n----------")

        print("\n\rProblem Source: ")
        print("\rProblem ID: ")
        print("\r")

	//Setup and Todo

        print("\n----------")
        onExit()
    }

}
