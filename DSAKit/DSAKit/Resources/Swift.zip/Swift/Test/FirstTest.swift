import XCTest
@testable import Source

final class FirstTest: XCTestCase {

    func test_firt() throws {
        XCTAssertTrue(1 == 1)
    }
    
}